# Sources-Vips
Isso sao scripts admins ro-ghoul by me
https://discord.gg/MX36juKaBR >>> meu server.
